<?php

/**
 * WordPress Sentry SDK Version.
 */
final class WP_Sentry_Version {
	public const SDK_IDENTIFIER = 'sentry.php.wp-sentry-integration';
	public const SDK_VERSION    = '3.10.0';
}
